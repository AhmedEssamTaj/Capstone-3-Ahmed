package com.example.capstone3.ApiResponse;

public class ApiException extends RuntimeException {

    public ApiException(String message){
        super(message);
    }
}
