package com.example.capstone3.DTO;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class RoleDTOout {
    private String name;
    private String volunteerName;
    private String event_name;
    private String description;


}
