package com.example.capstone3.DTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@AllArgsConstructor
@Getter
@Setter
public class VolunteerSkillsDTO {

    private String skillType;
}
