package com.example.capstone3.DTO;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class TrainingDTO {

    private String title;

    private String Descreption;

    private boolean isCompleted;
}
